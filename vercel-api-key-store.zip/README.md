# Vercel API Key Store
This project securely stores and retrieves API keys.